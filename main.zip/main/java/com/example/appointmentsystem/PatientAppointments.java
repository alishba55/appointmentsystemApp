package com.example.appointmentsystem;

public class PatientAppointments {
}
